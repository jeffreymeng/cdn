Thank you for downloading DurzoCraft!

This pack was created for the Texture a Day Challenge over 418 day. All daily releases can be seen here: http://imgur.com/a/Sr2oa

After the initial challenge, updates are made as they come out, check change log for details.

For information on the use of the pack for anything other than personal use please see "legal.txt" that resides in this folder. 

Author information:

Email: ndurzo64@gmail.com

Twitter: https://twitter.com/ndurzo64

YouTube: https://www.youtube.com/user/ndurzo64

